<?php

$config = [
	'name' => __('Trigger', 'rishi'),
	'visibilityKey' 	=> 'header_hide_trigger',
	'typography_keys' => ['trigger_typo'],
	'devices' => ['mobile'],
	'shortcut_style' => 'drop',
	'excluded_from' => ['offcanvas']
];
