<?php

$options = rishi__cb_customizer_get_options(
    \RISHI_CUSTOMIZER_BUILDER_DIR__ . '/panel-builder/header/menu/options.php',
    [
        'location' => 'Header Menu 2',
        'id' => '_two'
    ],
    false
);
