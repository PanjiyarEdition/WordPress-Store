<?php

$config = [
	'name' => __('Search', 'rishi'),
	'excluded_from' => ['offcanvas'],
	'visibilityKey' 	=> 'header_hide_search',
];
