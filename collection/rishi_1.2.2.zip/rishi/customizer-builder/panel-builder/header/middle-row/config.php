<?php

$config = [
	'name' => __('Main Row', 'rishi')
];
